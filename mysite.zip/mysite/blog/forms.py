# -*- coding:utf-8 -*-
from django import forms
from .models import Post, Comment
from django.views.generic.edit import FormView
from django.contrib.auth.forms import UserCreationForm

# Форма постов
class PostForm(forms.ModelForm):
	class Meta:
		model = Post
		fields = ('title', 'text','tags')

# Форма каментов		
class CommentForm(forms.ModelForm):
	class Meta:
		model = Comment
		fields = ('author', 'text')

# Форма регистрации
class RegisterFormView(FormView):
    form_class = UserCreationForm
    success_url = "/accounts/login/"
    template_name = "registration/register.html"

    def form_valid(self, form):
        form.save()
        return super(RegisterFormView, self).form_valid(form)


