# -*- coding:utf-8 -*-
from django import forms
from .models import Post, Comment
from snowpenguin.django.recaptcha2.fields import ReCaptchaField
from snowpenguin.django.recaptcha2.widgets import ReCaptchaWidget
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

# Форма постов
class PostForm(forms.ModelForm):
	class Meta:
		model = Post
		fields = ('title', 'text','tags')

# Форма каментов		
class CommentForm(forms.ModelForm):
	class Meta:
		model = Comment
		fields = ('author', 'text')

# Форма регистрации
class RegisterForm(UserCreationForm):
	username = forms.CharField(label="Логин")
	captcha = ReCaptchaField(widget=ReCaptchaWidget())
	class Meta:
		model = User
		fields = ('username',)
		
